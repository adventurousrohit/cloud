import { Link } from "react-router-dom";

const ResellerHostingWhyChoose = () => {
  return (
    <>
       <section className="pt-60 pb-60">
        <div className="pb-60">
            <div className="container">
                <div className="row g-3 align-items-center">
                    <h3>Why Choose Cloudminister for Reseller Hosting</h3>
                    <p>Surprise your consumers with hassle-free website implementation and leave the remains to us.</p>
                </div>
            </div>
        </div>
        <div className="container">
            <div className="row g-4">
                <div className="col-sm-6 col-lg-3" data-sal="slide-up" data-sal-duration="500" data-sal-delay="300" data-sal-easing="ease-in-out-sine">
                    <div className="card" style={{height:"100%"}}>
                        <div className="card-body p-xl-8">
                            <div className="hstack gap-3 mb-4">
                                <span className="d-inline-block flex-shrink-0">
                                    <img src="/img/icon-hosting-info-1.png" alt="image" className="img-fluid"/>
                                </span>
                                <h6 className="mb-0 flex-grow-1">
                                Fast & Easy Setup
                                </h6>
                            </div>
                            <p className="mb-0">
                            Begin Your Personal Reseller Hosting Business Without Any Prior Experience. 100% Beginner Cordial And Uncomplicated.
                            </p>
                        </div>
                    </div>
                </div>
                <div className="col-sm-6 col-lg-3" data-sal="slide-up" data-sal-duration="500" data-sal-delay="400" data-sal-easing="ease-in-out-sine">
                    <div className="card" style={{height:"100%"}}>
                        <div className="card-body p-xl-8">
                            <div className="hstack gap-3 mb-4">
                                <span className="d-inline-block flex-shrink-0">
                                    <img src="/img/cash.png" alt="image" className="img-fluid" style={{width:"56",height:"56px"}}/>
                                </span>
                                <h6 className="mb-0 flex-grow-1">
                                Earn More Money
                                </h6>
                            </div>
                            <p className="mb-0">
                            Triple Your ROI By Delivering Your Consumers Premium Web Hosting Packages Stuffed With Amazing Components And Domain Registrations.
                            </p>
                        </div>
                    </div>
                </div>
                <div className="col-sm-6 col-lg-3" data-sal="slide-up" data-sal-duration="500" data-sal-delay="500" data-sal-easing="ease-in-out-sine">
                    <div className="card" style={{height:"100%"}}>
                        <div className="card-body p-xl-8">
                            <div className="hstack gap-3 mb-4">
                                <span className="d-inline-block flex-shrink-0">
                                    <img src="/img/why-icon-3-dark.png" alt="image" className="img-fluid"/>
                                </span>
                                <h6 className="mb-0 flex-grow-1">
                                Overcome Your Competition
                                </h6>
                            </div>
                            <p className="mb-0">
                            Your Business, Supported By Our Flaming Fast Cloud Infrastructure (20x Faster Websites) Made To Authorize Your Victory.
                            </p>
                        </div>
                    </div>
                </div>
                <div className="col-sm-6 col-lg-3" data-sal="slide-up" data-sal-duration="500" data-sal-delay="500" data-sal-easing="ease-in-out-sine">
                    <div className="card" style={{height:"100%"}}>
                        <div className="card-body p-xl-8">
                            <div className="hstack gap-3 mb-4">
                                <span className="d-inline-block flex-shrink-0">
                                    <img src="/img/why-icon-3-dark.png" alt="image" className="img-fluid"/>
                                </span>
                                <h6 className="mb-0 flex-grow-1">
                                Unlimited Flexibility
                                </h6>
                            </div>
                            <p className="mb-0">
                            Get Absolute Freedom Over Your Business and Success. Set Your Own Pricing, Organize Your Own Packages, With Overselling Entitled.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </>
  )
};

export default ResellerHostingWhyChoose
